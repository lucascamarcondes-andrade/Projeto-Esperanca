// Máscaras simples para CPF, telefone e CEP
function setMask(input, maskFn) {
  input.addEventListener('input', function (e) {
    this.value = maskFn(this.value.replace(/\D/g, ''));
  });
}
function cpfMask(v) {
  v = v.replace(/\D/g, '').slice(0,11);
  return v.replace(/(\d{3})(\d)/, '$1.$2')
          .replace(/(\d{3})(\d)/, '$1.$2')
          .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
}
function telMask(v) {
  v = v.replace(/\D/g, '').slice(0,11);
  if (v.length <= 10) {
    return v.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3').replace(/-$/, '');
  }
  return v.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
}
function cepMask(v) {
  v = v.replace(/\D/g, '').slice(0,8);
  return v.replace(/(\d{5})(\d{3})/, '$1-$2');
}
window.addEventListener('DOMContentLoaded', function () {
  var cpf = document.getElementById('cpf');
  var tel = document.getElementById('telefone');
  var cep = document.getElementById('cep');
  if (cpf) setMask(cpf, cpfMask);
  if (tel) setMask(tel, telMask);
  if (cep) setMask(cep, cepMask);
  var form = document.getElementById('cadastroForm');
  if (form) {
    form.addEventListener('submit', function (e) {
      if (!form.checkValidity()) {
        e.preventDefault();
        form.reportValidity();
      }
    });
  }
});